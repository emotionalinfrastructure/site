# Navigation Model

The site should use a simple top navigation structure that places the work before the person and the evidence before the pitch. The recommended navigation sequence is Home, Framework, Standards, Research, Policy, Implementation, Downloads, and Contact.

The homepage should answer what EIT is and why it exists. The framework page should explain the system architecture. The standards page should prove that the work can be evaluated through normative language and conformance rules. The research page should demonstrate academic seriousness. The policy page should show institutional applicability. The implementation page should show buildability. The downloads page should provide controlled evidence access. The contact page should create a professional pathway for review and collaboration.

The footer should repeat the public status statement in compressed form. It should state that EIT is a candidate framework provided for research review, standards discussion, institutional evaluation, and implementation testing. It should not imply formal adoption, certification, or legal compliance approval unless those facts are separately documented.
