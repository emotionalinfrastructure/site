# Downloads and Artifact Library

The download library provides controlled access to the public-ready Emotional Infrastructure Telemetry portfolio materials. The library should not function as a file dump. Each document should have a title, version, status, intended audience, release condition, and short explanation of how it fits into the larger EIT governance system.

The first public tier should include the executive overview, the strongest protocol-level research manuscript, the foundation academic manuscript, the trajectory governance manuscript, and the standards seed document. This sequence gives readers a logical path from concept to research to standards and implementation.

The second public tier should include selected figures, appendices, schema summaries, audit traceability material, and conformance logic from the updated submission packages. These materials demonstrate that EIT has moved beyond theory into operational governance design.

The developer and revenue seed materials should not be broadly released until they complete security review, dependency review, README expansion, license selection, and public-facing documentation. This includes the SaaS prototype and SDK bundle. These assets are potentially valuable, but premature release would weaken credibility if the installation pathway, security posture, and licensing model are not complete.

The legal-adjacent contract rider should not be sold, published as legal advice, or used as a formal contract without attorney review. It can be referenced internally as a future commercial template candidate, but public release must use careful language.

Raw forensic logs and unredacted private records should remain private. These materials may have evidentiary or developmental value, but they are not appropriate for public portfolio release without redaction, minimization, chain-of-custody labeling, and security review.

## Public Release Labels

Each public download should use one of the following status labels: candidate draft, review-ready draft, CEITR-ready draft, submission-ready manuscript, internal working file, developer-private until security review, attorney-review required, public-ready overview, or public with legal disclaimers. These labels make the portfolio accurate and protect the work from overclaiming.
