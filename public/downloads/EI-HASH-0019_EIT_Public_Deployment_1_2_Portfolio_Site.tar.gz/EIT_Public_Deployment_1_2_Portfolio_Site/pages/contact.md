# Contact and Collaboration

For research review, standards discussion, institutional evaluation, implementation testing, publication inquiry, or professional collaboration, contact Brittany Wright regarding the Emotional Infrastructure Telemetry research and governance portfolio.

The strongest inquiries are specific. A useful message should identify the relevant area of interest, the organization or institution involved where applicable, the document or framework component being referenced, and the requested next step. General interest can be directed toward the framework overview. Academic review can be directed toward the research manuscripts. Standards feedback can be directed toward EIT Standard 0.1 and the conformance model. Institutional evaluation can be directed toward the policy layer and implementation model. Technical review can be directed toward schema, deterministic logic, audit traceability, and conformance testing.

The current collaboration posture is research discussion, governance review, standards-oriented feedback, institutional evaluation, and implementation assessment. The portfolio should not promise certification, legal compliance approval, formal standards recognition, or consulting deliverables unless those services are separately structured and accurately described.
